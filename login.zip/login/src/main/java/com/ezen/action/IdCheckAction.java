package com.ezen.action;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.ezen.dao.MemberDAO;



public class IdCheckAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		System.out.println(id);
		
		MemberDAO mDao = MemberDAO.getinstance();
		
		int result = mDao.confirmID(id); //MemberDAOì—� ì¶”ê°€
		
		request.setAttribute("id", id);
		request.setAttribute("result", result);
		
		//ì•„ì�´ë”” ì¤‘ë³µì²´í�¬í•˜ëŠ” idcheck.jsp ì‹¤í–‰
		String url = "join/idCheck.jsp";
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		

	}

}
