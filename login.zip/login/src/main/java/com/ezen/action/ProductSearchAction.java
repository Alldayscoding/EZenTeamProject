package com.ezen.action;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import com.ezen.dao.ProductDAO;
import com.ezen.vo.PageVO;
import com.ezen.vo.ProductVO;

public class ProductSearchAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("search_product");
		ProductDAO pDao = ProductDAO.getInstance();
		request.setAttribute("searchName", name);
		
		// 1. í™”ë©´ì „í™˜ ì‹œì—� ì¡°íšŒí•˜ëŠ” íŽ˜ì�´ì§€ë²ˆí˜¸ and í™”ë©´ì—� ê·¸ë ¤ì§ˆ ë�°ì�´í„°ê°œìˆ˜ 2ê°œë¥¼ ì „ë‹¬ë°›ì�Œ
		// ì²« íŽ˜ì�´ì§€ ê²½ìš°
		int pageNum = 1;
		int amount = 20;
			
		// íŽ˜ì�´ì§€ë²ˆí˜¸ë¥¼ í�´ë¦­í•˜ëŠ” ê²½ìš°
		if(request.getParameter("pageNum") != null && request.getParameter("amount") != null) {
			pageNum = Integer.parseInt(request.getParameter("pageNum"));
			amount = Integer.parseInt(request.getParameter("amount"));
		}
		
		List<ProductVO> list = pDao.productSearch("%"+name+"%", pageNum, amount);
		int searchCount = pDao.productSearchCount("%"+name+"%"); // ê²€ìƒ‰í•œ ìƒ�í’ˆ ìˆ˜

		// ê²€ìƒ‰í•œ ë�°ì�´í„°ê°€ ì¡´ìž¬í•  ë•Œ
		if(list.size() != 0) {
			PageVO pageVO = new PageVO(pageNum, amount, searchCount);
					
			// 3. íŽ˜ì�´ì§€ë„¤ì�´ì…˜ì�„ í™”ë©´ì—� ì „ë‹¬
			request.setAttribute("pageVO", pageVO);
					
			// í™”ë©´ì—� ê°€ì§€ê³  ë‚˜ê°ˆ listë¥¼ requestì—� ì €ìž¥
			request.setAttribute("searchList", list);
			request.setAttribute("searchCount", searchCount);
			
			String url = "/product/productSearch.jsp";
			RequestDispatcher dis = request.getRequestDispatcher(url);
			dis.forward(request, response);
		}else if(list.size() == 0) {
			String url = "/product/productSearchNull.jsp";
			RequestDispatcher dis = request.getRequestDispatcher(url);
			dis.forward(request, response);
		}
		
		
//		List<ProductVO> list = pDao.productSearch("%"+name+"%");
//		int searchCount = pDao.productSearchCount("%"+name+"%");
//
//		request.setAttribute("searchName", name);
//
//		if(list.size() != 0) {
//			request.setAttribute("searchList", list);
//			request.setAttribute("searchCount", searchCount);
//			
//			String url = "/product/productSearch.jsp";
//			RequestDispatcher dis = request.getRequestDispatcher(url);
//			dis.forward(request, response);
//			
//		}else if(list.size() == 0) {
//			String url = "/product/productSearchNull.jsp";
//			RequestDispatcher dis = request.getRequestDispatcher(url);
//			dis.forward(request, response);
//		}
		
		
	}

}
