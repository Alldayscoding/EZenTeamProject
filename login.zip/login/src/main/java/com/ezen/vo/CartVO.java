package com.ezen.vo;

import lombok.Data;

@Data
public class CartVO {
	String name;
	String img;
	int price;
}
