package com.ezen.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ezen.vo.CartVO;

public class CartAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String code = request.getParameter("num");
		String img = request.getParameter("img");
		int price = Integer.parseInt(request.getParameter("price").replaceAll("\\D", ""));
		
		List<CartVO> cartList = new ArrayList<CartVO>();
		
		CartVO cVo = new CartVO();
		System.out.println(code);
		cVo.setName(name);
		cVo.setImg(img);
		cVo.setPrice(price);
		
		cartList.add(cVo);

		System.out.println("cartList : " + cartList.size());
		
		
		request.setAttribute("cartList", cVo);

		
		String url  = "main?command=product_list";
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);
		
	}

}
