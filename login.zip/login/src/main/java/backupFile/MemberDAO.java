package backupFile;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.*;

public class MemberDAO {
    private static MemberDAO instance = new MemberDAO();
    private MemberDAO() {};
    public static MemberDAO getInstance() {return instance;}
    public Connection getConnection () throws SQLException, NamingException {

        Context initContext = new InitialContext();
        Context envContext  = (Context)initContext.lookup("java:/comp/env");
        DataSource ds = (DataSource)envContext.lookup("jdbc/oracle");
        Connection conn = ds.getConnection();
        return conn;

    }

    public int userCheck(String userid, String pwd) {
        int result = -1;
        String sql="SELECT pwd FROM member WHERE userid=?";

        Connection conn;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = getConnection(); //위에 getConnection 호출함으로써 dbcp & JNDI 사용
            pstmt = conn.prepareStatement(sql);

            //binding statement
            pstmt.setString(1, userid);
            rs = pstmt.executeQuery();

            if(rs.next()){
                String getPwd= rs.getString("pwd"); //1234
                if(getPwd != null && getPwd.equals(pwd)) {
                    result = 1;
                } else result = 0;
            }
            else result = -1;

        }catch (Exception e){ e.printStackTrace();}
        finally {
            try {
                if( rs!=null) rs.close();
                if (pstmt!=null) pstmt.close();
                if (rs!= null) rs.close();
            }catch (Exception e) {e.printStackTrace();}
        }
        return result;
    }

    public MemberVO getMember(String userid) {
        MemberVO vo = null;
        String sql = "SELECT * FROM member WHERE userid=?";
        Connection conn;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            conn=getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userid);
            rs = pstmt.executeQuery();

            if(rs.next()) {
                vo=new MemberVO();
                vo.setName(rs.getString("name"));
                vo.setUserid(rs.getString("userid"));
                vo.setPwd(rs.getString("pwd"));
                vo.setEmail(rs.getString("email"));
                vo.setPhone(rs.getString("phone"));
                vo.setAdmin(rs.getInt("admin"));
            }

        } catch(Exception e) {e.printStackTrace();}
        finally {
            try{
                if( rs!=null) rs.close();
                if (pstmt!=null) pstmt.close();
                if (rs!= null) rs.close();
            }catch (Exception e) {e.printStackTrace();}
        }
        return vo;

    }

    public int confirmID(String userid) {
        int result =-1;
        String sql = "select userid from member where userid=?";

        Connection conn;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn=getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userid);
            rs = pstmt.executeQuery();

            if(rs.next()) {
                result = 1;
            }
            else result = -1;

        } catch(Exception e) {e.printStackTrace();}
        finally {
            try{
                if( rs!=null) rs.close();
                if (pstmt!=null) pstmt.close();
                if (rs!= null) rs.close();
            }catch (Exception e) {e.printStackTrace();}
        }
        return result;

    }
}
