function plus() {
  count = document.frm.amount; // name이 amount인 요소
  sell_price = document.frm.sell_price; // name이 sell_price인 요소
  sum = document.frm_sum.sum;
  count.value++;
  sum.value = count.value * sell_price.value;
}

function minus() {
  count = document.frm.amount; // name이 amount인 요소
  sell_price = document.frm.sell_price; // name이 sell_price인 요소
  sum = document.frm_sum.sum;
  if (count.value > 1) {
    count.value--;
    sum.value = count.value * sell_price.value;
  } else {
    count.value = 1;
    alert("최소 수량은 1개입니다.");
  }
}

function onCart() {
  const productName = document.querySelector(".detail_name h2").textContent;
  const productImg = document.querySelector(".detail_img").src;
  const productPrice = document.querySelector('.sell_price[name="sum"]').value;
  const productCode = document.querySelector("#code").value;
  const productQty = document.querySelector("[name='amount']").value;

  console.log("productyQty : " + productQty);
  console.log("productPrice : " + productPrice);

  let onCart = confirm(
    "장바구니 추가 완료. 장바구니 페이지로 이동하시겠습니까?"
  );
  if (onCart) {
    location.href =
      "cart/cart.jsp?num=" +
      productCode +
      "&name=" +
      productName +
      "&img=" +
      productImg +
      "&price=" +
      productPrice +
      "&qty=" +
      productQty;
  }

  const url = window.location.href;
}

