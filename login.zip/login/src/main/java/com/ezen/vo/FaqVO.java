package com.ezen.vo;

import lombok.Data;

@Data
public class FaqVO {

		private String subject;
		private String content;
}
