package com.ezen.dao;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import org.jsoup.select.Elements;

import com.ezen.vo.FaqVO;

public class FaqDAO {

	private static FaqDAO instance = new FaqDAO();

	private FaqDAO() {}

	public static FaqDAO getinstance() {
		return instance;
	}

	public List<FaqVO> goCrawling() throws IOException{

		List<FaqVO> list = new ArrayList<>();
		FaqVO fVo = null; 

		for(int i=1; i<=1; i++) {	

		
			Document doc = Jsoup.connect("https://www.theskinfood.com/shop/faq.html").get();		
			//	Elements subject = doc.select("span.default-board__item-title");		//1íŽ˜ì�´ì§€ì—� ìžˆëŠ” ëª¨ë“  ì œëª©ë“¤.
			Elements subjects = doc.getElementsByClass("default-board__item-title");//1íŽ˜ì�´ì§€ì—� ìžˆëŠ” ëª¨ë“  ì œëª©ë“¤.
			/*
			 * <span class="default-board__item-title"> <span class="cat">[íšŒì›�ì •ë³´/ë©¤ë²„ì‹­]</span> í�¬ì�¸íŠ¸ ìœ íš¨ê¸°ê°„ì�€ ì–´ë–»ê²Œ ë�˜ë‚˜ìš”?</span>
			<span class="default-board__item-title"> <span class="cat">[ì�´ë²¤íŠ¸/ì¿ í�°]</span> í�¬ì�¸íŠ¸ ì†Œë©¸ê¸°ê°„ì�´ ìžˆë‚˜ìš”?</span>
			<span class="default-board__item-title"> <span class="cat">[ì£¼ë¬¸/ê²°ì œ/ë°°ì†¡]</span> ë°°ì†¡ì�¼ì�€ ì–¼ë§ˆë‚˜ ê±¸ë¦¬ë‚˜ìš”?</span>
			 * */

			Elements contents = doc.select("li.default-board__content.hide");//1íŽ˜ì�´ì§€ì—� ìžˆëŠ” ëª¨ë“  contentë“¤.

			//System.out.println(contents.text());
			//Element content = contents.get(1);
			//			System.out.println(content.text()); //í•˜ë‚˜ë§Œ ë¶ˆëŸ¬ì˜¤ëŠ”ê²ƒ.


			for (int j=0; j<20; j++) {
				fVo = new FaqVO();
				fVo.setSubject(subjects.get(j).text());
				fVo.setContent(contents.get(j).text());

				list.add(fVo);
			}


		}
		return list;

	}
}
