package com.ezen.action;

import java.io.IOException;

import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import com.ezen.dao.FaqDAO;
import com.ezen.vo.FaqVO;

public class FAQAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		FaqDAO fDao = FaqDAO.getinstance();
		List<FaqVO> list = fDao.goCrawling();

		request.setAttribute("FAQList", list);

		String url  = "FAQ/faq.jsp";
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);
		
	}

}
