package com.ezen.action;

import java.io.IOException;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.ezen.dao.MemberDAO;
import com.ezen.vo.MemberVO;



public class MemberUpdateAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8"); //�ѱ۱������ʰ�
		
		String id= request.getParameter("id");
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");

		
		
		MemberVO vo = new MemberVO();
		vo.setId(id);
		vo.setName(name);
		vo.setPass(pass);
		vo.setPhone(phone);
		vo.setEmail(email);
		
		
		//DB ����
		MemberDAO mDao = MemberDAO.getinstance();//��ü����
		mDao.updateMember(vo);  //MemberDAO ���Ͽ� ����
		
		String url="main?command=pass_check_form";
		response.sendRedirect(url);

	}

}