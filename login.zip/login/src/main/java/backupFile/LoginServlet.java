package backupFile;

import java.io.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;


@WebServlet(name = "LoginServlet", value = "/Login.do")
public class LoginServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {}
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String url = "login.jsp";
        String userid = request.getParameter("userid");
        String pwd = request.getParameter("pwd");

        MemberDAO mDAO = MemberDAO.getInstance();
        int result = mDAO.userCheck(userid,pwd);

        switch (result) {

            case 1:
                MemberVO mVO = mDAO.getMember(userid);
                HttpSession session = request.getSession();
                session.setAttribute("loginUser", mVO);
                request.setAttribute("message", "로그인성공");
                url = "main.jsp";
                break;
            case 0:
                request.setAttribute("userid", userid);
                request.setAttribute("message", "비번이 틀리다 임마..");
                break;
            case -1:
                request.setAttribute("message", "아이디 못찼겠다 임마.");
                break;
        }
        RequestDispatcher dis = request.getRequestDispatcher(url);
        dis.forward(request, response);

    }

}