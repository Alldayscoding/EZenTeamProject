package com.ezen.action;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.ezen.dao.MemberDAO;
import com.ezen.vo.MemberVO;


public class UserCheckAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = "login/login.jsp";
		String id= request.getParameter("id");
		String pass= request.getParameter("pass");

		
		MemberDAO mDao = MemberDAO.getinstance();
		int result = mDao.userCheck(id,pass);

		if(id == null) {
			request.setAttribute("message", " ");
			
		}else if(result == 1) {
			
			MemberVO mVo= mDao.getMember(id);
			
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", mVo);
			
			url = "main/main.jsp";
			
		}else if (result == 0) {
		
			request.setAttribute("id", id);
			request.setAttribute("message", "ë¹„ë²ˆì�´ ë¶ˆì�¼ì¹˜í•©ë‹ˆë‹¤.");
			
		}else{
			request.setAttribute("message", "ì¡´ìž¬í•˜ì§€ ì•ŠëŠ” ì•„ì�´ë”” ìž…ë‹ˆë‹¤.");
		}
		
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);

	}

}
