package backupFile;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "idCheckServlet", value = "/idCheck.do")
public class idCheckServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String userid = request.getParameter("userid");

        MemberDAO mDAO = MemberDAO.getInstance();

        int result = mDAO.confirmID(userid);

        request.setAttribute("userid", userid);
        request.setAttribute("result", result);

        RequestDispatcher dis = request.getRequestDispatcher("idcheck.jsp");
        dis.forward(request,response);
    }


}